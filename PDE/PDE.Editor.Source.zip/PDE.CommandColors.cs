// PDE modification, 2026-11-04. MIT license inherited from PSReadLine.
using System;
using System.Collections.Generic;
using System.Management.Automation.Language;
namespace PDE.PowerShell {
 public static class PDECommandColors {
  public static bool CharacterMode { get; set; } = true;
  public static int MaximumDistance { get; set; } = 2;
  public static bool Enabled { get; set; }
  public static bool DiscoveryHealthy { get; set; }
  private static HashSet<string> names=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
  private static HashSet<string> prefixes=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
  private static HashSet<string> successful=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
  private static int[] map=new int[0];
  public static readonly string[] Palette={"\x1b[37m","\x1b[38;2;255;165;0m","\x1b[91m","\x1b[92m"};
  public static void SetIndex(string[] commands,string[] success,bool healthy) {
   var n=new HashSet<string>(commands??new string[0],StringComparer.OrdinalIgnoreCase);
   var p=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
   foreach(var name in n) for(int i=1;i<=name.Length;i++)p.Add(name.Substring(0,i));
   names=n;prefixes=p;successful=new HashSet<string>(success??new string[0],StringComparer.OrdinalIgnoreCase);DiscoveryHealthy=healthy;
  }
  public static int Classify(string name) {
   if(string.IsNullOrEmpty(name))return 0;
   if(names.Contains(name))return successful.Contains(name)?3:1;
   if(prefixes.Contains(name)||!DiscoveryHealthy||name.IndexOfAny(new[]{'\\','/',':'})>=0||name[0]=='.')return 1;
   return 2;
  }
  public static void Prepare(Ast ast,string text) {
   map=new int[text.Length];if(!Enabled||ast==null)return;
   var local=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
   foreach(var node in ast.FindAll(a=>a is FunctionDefinitionAst,true))local.Add(((FunctionDefinitionAst)node).Name);
   foreach(var node in ast.FindAll(a=>a is CommandAst,true)) {
    var cmd=(CommandAst)node;var name=cmd.GetCommandName();if(name==null||cmd.CommandElements.Count==0)continue;
    var code=Classify(name);if(local.Contains(name)&&code!=3)code=1;
    var extent=cmd.CommandElements[0].Extent;
    int start = extent.StartOffset;
    var raw = extent.Text;
    bool literal = raw == name;
    if (raw.Length == name.Length + 2 && (raw[0] == '\'' || raw[0] == '"') &&
        raw[raw.Length - 1] == raw[0] && raw.Substring(1, name.Length) == name) {
        literal = true;
        start++;
    }
    if (CharacterMode && literal) {
        int[] letters = PDECharacterColoring.Map(name, names, successful,
            prefixes.Contains(name) || local.Contains(name), code == 1, MaximumDistance);
        Array.Copy(letters, 0, map, start, letters.Length);
    } else {
        for (int i = extent.StartOffset; i < extent.EndOffset; i++) map[i] = code;
    }
   }
  }
  public static string ColorAt(int offset){int code = offset >= 0 && offset < map.Length ? map[offset] : 0; return CharacterMode && code == 0 ? VTColorUtils.DefaultColor : Palette[code];}
  public static int[] GetMap(string text){Token[] t;ParseError[] e;Prepare(Parser.ParseInput(text,out t,out e),text);return (int[])map.Clone();}
 }
}
